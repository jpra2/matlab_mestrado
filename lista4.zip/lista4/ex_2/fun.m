% --------------------------------------------------------------------------
% Funcoes locais:
%
  function f = fun(x)
%
% func.m  funcao fornecida para encontrar a raiz.
%
  f = (x.^2).*sin(x);
  end
