function x = zeros(x)
% In Package myAD - Automatic Differentiation
% by Martin Fink, May 2007
% martinfink 'at' gmx.at

    x.values = x.values*0;
    x.derivatives = x.derivatives*0;
